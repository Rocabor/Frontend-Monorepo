import React, { useState, useMemo } from 'react';
import { 
  Terminal, 
  Code, 
  Verified, 
  Sparkles, 
  Briefcase, 
  FileCode, 
  ArrowUp, 
  ArrowRight, 
  Github, 
  Linkedin, 
  Twitter, 
  ExternalLink, 
  Layers, 
  Eye, 
  Award,
  BookOpen
} from 'lucide-react';
import { PROJECTS_DATA } from './data';
import { Category, Project } from './types';
import ProjectDetailModal from './components/ProjectDetailModal';
import ResumeModal from './components/ResumeModal';
import MonorepoExplorer from './components/MonorepoExplorer';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<Category>('Newbie');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest'>('newest');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isResumeOpen, setIsResumeOpen] = useState(false);

  // Filter & sort logic
  const filteredProjects = useMemo(() => {
    const list = PROJECTS_DATA.filter(p => p.category === selectedCategory);
    if (sortBy === 'oldest') {
      return [...list].reverse();
    }
    return list;
  }, [selectedCategory, sortBy]);

  // Featured project in active category
  const featuredProject = useMemo(() => {
    return filteredProjects.find(p => p.isFeatured) || null;
  }, [filteredProjects]);

  // Regular projects (non-featured or all if none featured)
  const regularProjects = useMemo(() => {
    if (featuredProject) {
      return filteredProjects.filter(p => p.id !== featuredProject.id);
    }
    return filteredProjects;
  }, [filteredProjects, featuredProject]);

  // Dynamic header summaries
  const categorySummary = {
    Newbie: {
      count: '08 REPOS',
      subtitle: 'Foundations of CSS Layout & Responsive Design',
      desc: 'Foundational layouts, basic interactivity, and semantic HTML mastery.'
    },
    Junior: {
      count: '12 REPOS',
      subtitle: 'Dynamic State Engines & Interactive Web Application Layouts',
      desc: 'Responsive designs with complex grids and dynamic data fetching.'
    },
    Intermediate: {
      count: '06 REPOS',
      subtitle: 'Advanced Centralized Architectures & API Integrations',
      desc: 'State management, API integration, and performance optimization.'
    },
    Advanced: {
      count: '04 REPOS',
      subtitle: 'Enterprise-grade Monorepo Modules & Full-Stack Systems',
      desc: 'Full-stack features, complex logic, and high-fidelity animations.'
    }
  }[selectedCategory];

  const handleScrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-surface text-on-surface font-sans antialiased relative selection:bg-primary/20 selection:text-primary">
      
      {/* Top Header Bar */}
      <header className="fixed top-0 w-full z-40 bg-[#0f1418]/85 backdrop-blur-xl border-b border-white/5">
        <div className="flex justify-between items-center h-20 px-4 md:px-6 max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <span className="font-display font-extrabold text-lg md:text-xl text-primary tracking-tighter tech-gradient select-none">
              My Frontend Journey
            </span>
            <div className="hidden lg:flex items-center gap-2 px-3 border-l border-white/10 ml-3">
              <Code className="w-4 h-4 text-primary" />
              <span className="text-on-surface-variant font-mono text-[11px] font-medium uppercase tracking-wider">
                React • TS • Tailwind
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-6">
            {(['Newbie', 'Junior', 'Intermediate', 'Advanced'] as Category[]).map(cat => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => {
                    setSelectedCategory(cat);
                    handleScrollToSection('journey-section');
                  }}
                  className={`text-xs font-semibold font-display tracking-wide pb-1 transition-all ${
                    isActive 
                      ? 'text-primary border-b-2 border-primary' 
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            <button 
              onClick={() => handleScrollToSection('monorepo-viewer')}
              className="p-2 rounded-full hover:bg-white/5 text-on-surface-variant hover:text-primary transition-colors cursor-pointer"
              title="Inspect Code Monorepo"
            >
              <Terminal className="w-4.5 h-4.5" />
            </button>
            <button 
              onClick={() => handleScrollToSection('monorepo-viewer')}
              className="p-2 rounded-full hover:bg-white/5 text-on-surface-variant hover:text-primary transition-colors cursor-pointer"
              title="View Workspace"
            >
              <Code className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="pt-32 pb-20 space-y-24">

        {/* HERO SECTION */}
        <section className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            
            {/* Hero details */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/25 text-primary">
                <Verified className="w-4 h-4" />
                <span className="font-mono text-[10px] font-bold uppercase tracking-widest">
                  PROFESSIONAL MONOREPO
                </span>
              </div>
              <h1 className="font-display font-extrabold text-3xl md:text-5xl text-on-surface leading-[1.1] tracking-tight">
                Crafting <span className="tech-gradient">High-Performance</span> Interfaces Through Intentional Growth.
              </h1>
              <p className="text-on-surface-variant text-sm md:text-base leading-relaxed max-w-xl">
                This monorepo serves as a technical log of my frontend evolution. From foundational components to complex state-driven architectures, every line of code prioritizes scalability, clean patterns, and developer experience.
              </p>
              
              {/* CTAs */}
              <div className="flex gap-4 pt-2">
                <button 
                  onClick={() => handleScrollToSection('monorepo-viewer')}
                  className="bg-primary hover:bg-primary-container text-on-primary font-display font-bold text-xs uppercase tracking-wider px-6 py-3 rounded-lg hover:brightness-105 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 fill-current" /> View Monorepo
                </button>
                <button 
                  onClick={() => setIsResumeOpen(true)}
                  className="border border-white/10 hover:border-white/20 bg-white/5 px-6 py-3 rounded-lg font-display font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Briefcase className="w-4 h-4" /> Resume
                </button>
              </div>
            </div>

            {/* Static Code Mock Card */}
            <div className="relative w-full">
              <div className="absolute -inset-4 bg-primary/5 blur-3xl rounded-full"></div>
              <div className="glass-card p-6 rounded-2xl relative overflow-hidden">
                <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
                  <div className="flex gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/40"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/40"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-green-500/40"></span>
                  </div>
                  <span className="text-[10px] text-on-surface-variant/50 font-mono">architecture.config.js</span>
                </div>
                <div className="space-y-3 font-mono text-xs md:text-sm leading-relaxed text-on-surface-variant">
                  <p className="text-primary"><span className="text-tertiary">const</span> portfolio = {'{'}</p>
                  <p className="pl-4">tech: [<span className="text-secondary">"React"</span>, <span className="text-secondary">"Tailwind"</span>, <span className="text-secondary">"Next.js"</span>],</p>
                  <p className="pl-4">focus: <span className="text-secondary font-bold">"Clean Architecture"</span>,</p>
                  <p className="pl-4">patterns: [<span className="text-secondary">"Atomic Design"</span>, <span className="text-secondary">"TDD"</span>],</p>
                  <p className="text-primary">{'};'}</p>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* JOURNEY SELECTOR CATEGORIES */}
        <section className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Newbie Card */}
            <div 
              onClick={() => setSelectedCategory('Newbie')}
              className={`glass-card p-6 rounded-2xl flex flex-col group cursor-pointer border-l-4 transition-all hover:scale-[1.02] ${
                selectedCategory === 'Newbie' ? 'border-l-primary bg-primary/5' : 'border-l-primary/40'
              }`}
            >
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-4">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-display font-bold text-base text-on-surface mb-1">Newbie</h3>
              <p className="text-on-surface-variant text-xs leading-relaxed">
                Foundational layouts, basic interactivity, and semantic HTML mastery.
              </p>
              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                <span className="text-primary font-bold">08 PROJECTS</span>
                <ArrowRight className="w-3.5 h-3.5 text-on-surface-variant group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Junior Card */}
            <div 
              onClick={() => setSelectedCategory('Junior')}
              className={`glass-card p-6 rounded-2xl flex flex-col group cursor-pointer border-l-4 transition-all hover:scale-[1.02] ${
                selectedCategory === 'Junior' ? 'border-l-secondary bg-secondary/5' : 'border-l-secondary/40'
              }`}
            >
              <div className="w-10 h-10 bg-secondary/10 rounded-xl flex items-center justify-center text-secondary mb-4">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="font-display font-bold text-base text-on-surface mb-1">Junior</h3>
              <p className="text-on-surface-variant text-xs leading-relaxed">
                Responsive designs with complex grids and dynamic data fetching.
              </p>
              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                <span className="text-secondary font-bold">12 PROJECTS</span>
                <ArrowRight className="w-3.5 h-3.5 text-on-surface-variant group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Intermediate Card */}
            <div 
              onClick={() => setSelectedCategory('Intermediate')}
              className={`glass-card p-6 rounded-2xl flex flex-col group cursor-pointer border-l-4 transition-all hover:scale-[1.02] ${
                selectedCategory === 'Intermediate' ? 'border-l-tertiary bg-tertiary/5' : 'border-l-tertiary/40'
              }`}
            >
              <div className="w-10 h-10 bg-tertiary/10 rounded-xl flex items-center justify-center text-tertiary mb-4">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="font-display font-bold text-base text-on-surface mb-1">Intermediate</h3>
              <p className="text-on-surface-variant text-xs leading-relaxed">
                State management, API integration, and performance optimization.
              </p>
              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                <span className="text-tertiary font-bold">06 PROJECTS</span>
                <ArrowRight className="w-3.5 h-3.5 text-on-surface-variant group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Advanced Card */}
            <div 
              onClick={() => setSelectedCategory('Advanced')}
              className={`glass-card p-6 rounded-2xl flex flex-col group cursor-pointer border-l-4 transition-all hover:scale-[1.02] ${
                selectedCategory === 'Advanced' ? 'border-l-error bg-error/5' : 'border-l-error/40'
              }`}
            >
              <div className="w-10 h-10 bg-error/10 rounded-xl flex items-center justify-center text-error mb-4">
                <Award className="w-5 h-5" />
              </div>
              <h3 className="font-display font-bold text-base text-on-surface mb-1">Advanced</h3>
              <p className="text-on-surface-variant text-xs leading-relaxed">
                Full-stack features, complex logic, and high-fidelity animations.
              </p>
              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                <span className="text-error font-bold">04 PROJECTS</span>
                <ArrowRight className="w-3.5 h-3.5 text-on-surface-variant group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

          </div>
        </section>

        {/* ACTIVE PROJECT CHALLENGES SECTION */}
        <section id="journey-section" className="max-w-7xl mx-auto px-4 md:px-6 scroll-mt-24">
          
          {/* Section Header Controls */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-white/5 pb-6">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <h2 className="font-display font-extrabold text-xl md:text-2xl uppercase tracking-wider text-on-surface">
                  {selectedCategory}
                </h2>
                <span className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold border ${
                  selectedCategory === 'Newbie' ? 'bg-primary/10 text-primary border-primary/20' :
                  selectedCategory === 'Junior' ? 'bg-secondary/10 text-secondary border-secondary/20' :
                  selectedCategory === 'Intermediate' ? 'bg-tertiary/10 text-tertiary border-tertiary/20' :
                  'bg-error/10 text-error border-error/20'
                }`}>
                  {categorySummary.count}
                </span>
              </div>
              <p className="text-xs md:text-sm text-on-surface-variant font-mono">
                {categorySummary.subtitle}
              </p>
            </div>

            {/* Sort Toggle Controls */}
            <div className="flex items-center gap-1 bg-surface-container p-1 rounded-lg border border-white/5 max-w-fit">
              <button 
                onClick={() => setSortBy('newest')}
                className={`px-4 py-2 rounded-md font-display font-bold text-xs cursor-pointer transition-all ${
                  sortBy === 'newest' ? 'bg-surface-container-highest text-primary' : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                Newest
              </button>
              <button 
                onClick={() => setSortBy('oldest')}
                className={`px-4 py-2 rounded-md font-display font-bold text-xs cursor-pointer transition-all ${
                  sortBy === 'oldest' ? 'bg-surface-container-highest text-primary' : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                Oldest
              </button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={selectedCategory + sortBy}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              
              {/* FEATURED CHALLENGE IF APPLICABLE */}
              {featuredProject && (
                <div 
                  onClick={() => setSelectedProject(featuredProject)}
                  className="glass-card rounded-2xl overflow-hidden flex flex-col lg:flex-row group cursor-pointer transition-all hover:border-white/20"
                >
                  <div className="lg:w-3/5 overflow-hidden relative h-56 lg:h-auto">
                    <img 
                      src={featuredProject.image} 
                      alt={featuredProject.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-surface/90 to-transparent"></div>
                  </div>

                  <div className="lg:w-2/5 p-6 md:p-8 flex flex-col justify-center space-y-4">
                    <div className="flex gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-widest bg-primary/10 text-primary border border-primary/20 uppercase">
                        Featured
                      </span>
                      {featuredProject.tags.slice(0, 2).map(tag => (
                        <span key={tag} className="px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-widest bg-white/5 text-on-surface-variant border border-white/5 uppercase">
                          {tag}
                        </span>
                      ))}
                    </div>
                    
                    <h3 className="font-display font-extrabold text-lg md:text-xl text-on-surface leading-tight tracking-tight">
                      {featuredProject.title}
                    </h3>
                    <p className="text-on-surface-variant text-xs md:text-sm leading-relaxed">
                      {featuredProject.description}
                    </p>

                    <div className="flex gap-4 items-center border-t border-white/5 pt-4 text-xs font-mono text-on-surface-variant">
                      <span className="flex items-center gap-1 hover:text-primary transition-colors">
                        <Eye className="w-4 h-4" /> Live Preview
                      </span>
                      <span className="flex items-center gap-1 hover:text-primary transition-colors">
                        <Terminal className="w-4 h-4" /> Source Code
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* REGULAR PROJECTS GRID */}
              {regularProjects.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {regularProjects.map(project => (
                    <div 
                      key={project.id}
                      onClick={() => setSelectedProject(project)}
                      className="glass-card rounded-2xl overflow-hidden group cursor-pointer transition-all hover:border-white/20 flex flex-col justify-between"
                    >
                      <div>
                        <div className="h-44 overflow-hidden relative">
                          <img 
                            src={project.image} 
                            alt={project.title} 
                            className="w-full h-full object-cover group-hover:scale-[1.04] transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-surface/40 to-transparent"></div>
                        </div>

                        <div className="p-5 space-y-3">
                          <h4 className="font-display font-bold text-sm md:text-base text-on-surface tracking-tight group-hover:text-primary transition-colors">
                            {project.title}
                          </h4>
                          <p className="text-on-surface-variant text-xs leading-relaxed line-clamp-2">
                            {project.description}
                          </p>
                        </div>
                      </div>

                      <div className="p-5 pt-0 space-y-4">
                        <div className="flex flex-wrap gap-1.5">
                          {project.tags.map(tag => (
                            <span key={tag} className="text-[9px] font-mono bg-white/5 text-on-surface-variant/80 px-2 py-0.5 rounded border border-white/5">
                              {tag}
                            </span>
                          ))}
                        </div>

                        <div className="flex justify-between items-center border-t border-white/5 pt-3.5">
                          <span className="text-[10px] font-mono text-primary flex items-center gap-1 font-bold">
                            <Sparkles className="w-3 h-3 fill-current" /> EXPLORE DEMO
                          </span>
                          <div className="flex gap-2 text-on-surface-variant">
                            <ExternalLink className="w-3.5 h-3.5 hover:text-primary transition-colors" />
                            <Code className="w-3.5 h-3.5 hover:text-primary transition-colors" />
                          </div>
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 border border-dashed border-white/10 rounded-2xl space-y-3">
                  <Terminal className="w-10 h-10 text-on-surface-variant/40 mx-auto" />
                  <p className="text-xs text-on-surface-variant font-mono">
                    Coming Soon! Additional challenges are currently being staged in the local directory.
                  </p>
                </div>
              )}

            </motion.div>
          </AnimatePresence>

        </section>

        {/* MONOREPO CODE EXPLORER SECTIONS */}
        <section id="monorepo-viewer" className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="space-y-6">
            <div className="space-y-1">
              <h2 className="font-display font-extrabold text-xl md:text-2xl tracking-tight text-on-surface uppercase">
                Inspect Monorepo Architecture
              </h2>
              <p className="text-xs md:text-sm text-on-surface-variant font-mono">
                Click folders and files to inspect exact code snippets designed during this challenge journey.
              </p>
            </div>

            <MonorepoExplorer 
              projects={PROJECTS_DATA}
              onSelectProject={(p) => setSelectedProject(p)}
            />
          </div>
        </section>

        {/* FOOTER CTA INDICATOR */}
        <section className="flex flex-col items-center justify-center py-6">
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="glass-card p-4 rounded-full flex flex-col items-center gap-1 group hover:scale-110 cursor-pointer"
          >
            <ArrowUp className="w-4 h-4 text-primary animate-bounce" />
            <span className="text-[9px] font-mono tracking-widest text-on-surface-variant group-hover:text-primary transition-colors">
              TOP
            </span>
          </button>
        </section>

      </main>

      {/* FOOTER BAR */}
      <footer className="bg-surface-container-lowest py-8 border-t border-white/5">
        <div className="flex flex-col md:flex-row justify-between items-center px-4 md:px-6 max-w-7xl mx-auto gap-6">
          <div className="flex flex-col items-center md:items-start gap-1">
            <span className="font-display font-extrabold text-base text-primary tech-gradient">
              My Frontend Journey
            </span>
            <p className="text-on-surface-variant font-mono text-[10px]">
              © 2026 My Frontend Journey. Built for the modern web with premium standards.
            </p>
          </div>

          <div className="flex gap-4">
            <a href="#" className="text-on-surface-variant hover:text-primary transition-colors flex items-center gap-1.5 font-mono text-[11px]">
              <Github className="w-4 h-4" /> GitHub
            </a>
            <a href="#" className="text-on-surface-variant hover:text-primary transition-colors flex items-center gap-1.5 font-mono text-[11px]">
              <Linkedin className="w-4 h-4" /> LinkedIn
            </a>
            <a href="#" className="text-on-surface-variant hover:text-primary transition-colors flex items-center gap-1.5 font-mono text-[11px]">
              <Code className="w-4 h-4" /> FM Profile
            </a>
            <a href="#" className="text-on-surface-variant hover:text-primary transition-colors flex items-center gap-1.5 font-mono text-[11px]">
              <Twitter className="w-4 h-4" /> Twitter
            </a>
          </div>
        </div>
      </footer>

      {/* MODAL WRAPPERS */}
      <AnimatePresence>
        {selectedProject && (
          <ProjectDetailModal 
            project={selectedProject}
            onClose={() => setSelectedProject(null)}
          />
        )}
        {isResumeOpen && (
          <ResumeModal 
            onClose={() => setIsResumeOpen(false)}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
