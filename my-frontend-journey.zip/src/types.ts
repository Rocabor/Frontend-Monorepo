export type Category = 'Newbie' | 'Junior' | 'Intermediate' | 'Advanced';

export interface ProjectFile {
  name: string;
  language: string;
  content: string;
}

export interface Project {
  id: string;
  title: string;
  category: Category;
  description: string;
  image: string;
  tags: string[];
  isFeatured: boolean;
  liveUrl: string;
  sourceUrl: string;
  difficulty: string;
  difficultyColor: string; // Tailwind color class for borders/text e.g. 'primary', 'secondary', etc.
  playgroundId?: string; // Links to an interactive live widget in our app
  files: ProjectFile[];
  metrics: {
    duration: string;
    complexity: string;
    linesOfCode: number;
  };
}

export interface SkillCategory {
  name: string;
  skills: string[];
  level: number; // 0 to 100
}

export interface Experience {
  role: string;
  company: string;
  period: string;
  description: string[];
  tags: string[];
}
