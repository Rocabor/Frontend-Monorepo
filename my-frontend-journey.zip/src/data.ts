import { Project, Experience } from './types';

export const PROJECTS_DATA: Project[] = [
  {
    id: 'intro-signup',
    title: 'Intro component with signup form',
    category: 'Newbie',
    description: 'Mastering input validation, flexbox layouts, and accessible form structures. This project focuses on pixel-perfect mobile-first implementation and clean CSS architecture.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDqthpHaBXLJWK1kIdl_P0YtNQNJeH9aek2eB5gMsgvBBateVEDA_JDgxLCSt3OawaxqjuTWCZ4Rk_wBrICi4NvgDr4pas63ynAXE521RPH9kic2nfFC55T7fOvoYXZZ1RF92_ztaZW2wDdeIRUGARr9y5cIr7cuw_or4nXexv4d9Wb4w3DnxlSUBsv_zGZzrLipOmaANTXAdS9KWAnXBApSmz-1o61tmYhX_LuqWra-bKk85vrrMUN',
    tags: ['Featured', 'HTML/CSS', 'JS'],
    isFeatured: true,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Newbie',
    difficultyColor: 'primary',
    playgroundId: 'intro-signup',
    metrics: { duration: '2 days', complexity: 'Low', linesOfCode: 320 },
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!-- Signup Form Section -->
<section class="signup-container">
  <div class="intro-text">
    <h1>Learn to code by watching others</h1>
    <p>See how experienced developers solve problems in real-time. Watching scripted tutorials is great, but understanding how developers think is invaluable.</p>
  </div>
  <div class="form-wrapper">
    <div class="promo-banner">
      <p><strong>Try it free 7 days</strong> then $20/mo. thereafter</p>
    </div>
    <form id="signupForm" class="card">
      <div class="input-group">
        <input type="text" id="firstName" placeholder="First Name" required />
        <span class="error-icon">!</span>
        <p class="error-msg">First Name cannot be empty</p>
      </div>
      <div class="input-group">
        <input type="text" id="lastName" placeholder="Last Name" required />
        <span class="error-icon">!</span>
        <p class="error-msg">Last Name cannot be empty</p>
      </div>
      <button type="submit" class="btn-submit">Claim your free trial</button>
    </form>
  </div>
</section>`
      },
      {
        name: 'styles.css',
        language: 'css',
        content: `.signup-container {
  display: flex;
  align-items: center;
  gap: 2rem;
  max-width: 1100px;
  margin: 0 auto;
}
.promo-banner {
  background-color: var(--color-secondary-container);
  border-radius: 8px;
  padding: 1.25rem;
  text-align: center;
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
}
.btn-submit {
  background-color: #38bdf8;
  color: white;
  font-weight: 600;
  text-transform: uppercase;
  border-radius: 6px;
  cursor: pointer;
  transition: opacity 0.2s ease;
}
.btn-submit:hover {
  opacity: 0.9;
}`
      }
    ]
  },
  {
    id: 'pod-request',
    title: 'Pod request access',
    category: 'Newbie',
    description: 'Custom input styling and complex responsive grid systems for a modern podcast landing page with client-side access control.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD7Bae3GR7vuWkbd5favNrqKMdkgqCo3EXlygEaZ6yEzvjup-HKxf4CMxGdDgChHo39nfFYE_4uAeTWuILiV1aEkXojTbRN7NJeSp2xdxEWUt6Q655zMiOPudz0Ch35F-nyAe1oJlTLPzRu6_cdGEzbtJAXdlx-JHPZ69Lv4rGjbsbweirHBTwAjzzLdCvnLRbtz68t_MZMkX_ONg71GTfdFHhbvqfBnQRFX-xWvW4EK3bmODvWugzL',
    tags: ['HTML', 'CSS', 'JS'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Newbie',
    difficultyColor: 'primary',
    playgroundId: 'pod-request',
    metrics: { duration: '3 days', complexity: 'Low', linesOfCode: 240 },
    files: [
      {
        name: 'app.js',
        language: 'javascript',
        content: `const form = document.querySelector('form');
const emailInput = document.querySelector('#email');
const errorMsg = document.querySelector('.error-text');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const emailVal = emailInput.value.trim();
  const emailPattern = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  
  if (!emailPattern.test(emailVal)) {
    errorMsg.style.display = 'block';
    emailInput.classList.add('error-border');
  } else {
    errorMsg.style.display = 'none';
    emailInput.classList.remove('error-border');
    alert('Access Requested Successfully!');
  }
});`
      }
    ]
  },
  {
    id: 'rating-component',
    title: 'Rating Component',
    category: 'Newbie',
    description: 'Interactive state management with vanilla JS and DOM manipulation, styled using transparent background layering.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBgI6SfomRKT0_goVOzNNQ8FYmNEIlqn1GL3UedlFhd0rVfTORwyv-AEkKfOohqXt8LIgTQs3NCet15FBpR_UeCOfYOy3s7NABIhro0pc889AgLgQwr89oOg3ltxel3NcZ8pWWtlpxoee39XcMyu09y_tYbXA0tdVqv5ruFbb1am6ZPUq0uQZ-zIPrQzt8ag2s9qHyRTsH2hqXqRxfa-83WnIGs2_B1DJR6xy8m1KY4uzT3iUlhZGAS',
    tags: ['JS', 'DOM', 'Interactive'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Newbie',
    difficultyColor: 'primary',
    playgroundId: 'rating-component',
    metrics: { duration: '1 day', complexity: 'Low', linesOfCode: 120 },
    files: [
      {
        name: 'rating.ts',
        language: 'typescript',
        content: `let selectedRating: number | null = null;

export function initRating() {
  const stars = document.querySelectorAll('.star-number');
  stars.forEach(star => {
    star.addEventListener('click', () => {
      stars.forEach(s => s.classList.remove('active'));
      star.classList.add('active');
      selectedRating = parseInt(star.getAttribute('data-value') || '0');
    });
  });
}`
      }
    ]
  },
  {
    id: 'faq-accordion',
    title: 'FAQ Accordion',
    category: 'Newbie',
    description: 'Accessible accordion patterns focusing on aria-attributes and smooth CSS height transitions.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC5A5ae-q-CdqyljLRIdj6eq-nPSPrT6Xo9RFQV6B6w1k9MJSi5--07zAH9uqvn_OdIzes4B_Epu_WJ7aT3OFHHqVX-ZMCnId-0-j8yfiXc9RcH1PY4eIiJ8zrNx2u8w0HP4-omr-FwyFz81F-E3y8pdlMjvCTkGtiJknUZCOhSPhdkPhx-HQZRtD-I4j0cLl0KTLrs0jTUHUrs7w8MAj21I4WoMLBpp-crr1Wr0wC7u8Hf2TBoSW7M',
    tags: ['ARIA', 'A11Y', 'Transitions'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Newbie',
    difficultyColor: 'primary',
    playgroundId: 'faq-accordion',
    metrics: { duration: '1 day', complexity: 'Low', linesOfCode: 150 },
    files: [
      {
        name: 'accordion.html',
        language: 'html',
        content: `<div class="accordion-item">
  <button class="accordion-trigger" aria-expanded="false" aria-controls="faq-1">
    <span>What is Frontend Mentor?</span>
    <img src="icon-plus.svg" alt="Toggle" class="icon" />
  </button>
  <div id="faq-1" class="accordion-content" aria-hidden="true">
    <p>Frontend Mentor offers invaluable realistic practice. It bridges the gap between theory and actual real-world production projects.</p>
  </div>
</div>`
      }
    ]
  },
  {
    id: 'elearning-page',
    title: 'E-learning Page',
    category: 'Newbie',
    description: 'A multi-column feature grid showcasing card layout patterns, micro-interactions, and consistent branding.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBxNoXjicVIyuroPbALfo4ReO3d8kejPiAerfUmUMKOX-5xglojF10UTHWXpauQhPTofTuJcGwdmH3hRrFQ56Sx9dQRCTkKJRgP7PaBYPSiQ06_V7sbueOpReQJZiIxU95QJhOmbIFfrWfNSWJtCWCXR5X-UkmdQKi_KhURNXqXtBKfrMc_i9Yg-XDSuMzSusoffbDHLxWOGxGfVkcaimC5IuTHUgmQgDHGNseW0l_GptG79P6-ULOy',
    tags: ['Grid', 'SCSS', 'Card-Layout'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Newbie',
    difficultyColor: 'primary',
    playgroundId: 'elearning-page',
    metrics: { duration: '2 days', complexity: 'Low', linesOfCode: 450 },
    files: [
      {
        name: 'grid.scss',
        language: 'scss',
        content: `.course-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1.5rem;
  padding: 4rem 1rem;
}
.course-card {
  position: relative;
  border-radius: 12px;
  background: var(--color-surface-container);
  padding: 2rem 1.5rem;
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-8px);
  }
}`
      }
    ]
  },
  {
    id: 'workit-landing',
    title: 'Workit Landing',
    category: 'Newbie',
    description: 'Mastering absolute positioning, complex responsive asset management, and typography rhythm.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_QxQ1ZA9zBb6uWqmKQFVxFmziL5Ic_OhAeiotWiAhbwuRb2XcPasFjNhTYfhxll3MHwC9RrIREzYbTQLZbgCE_U96uateELlJNL2g5lnghU928WRzISSaNPdIM3o4Z4t9pRWXAeREAs3veJeKC2oYFxjj_ZOdBkQXkmqWoA_E3W7pJeL9y4AxtaVpBGGiuKAapqtCqh9xkIFukOEwZdiRddP-iOK3fIAFV6me_cRvGRjzlNwynMJr',
    tags: ['Flexbox', 'BEM', 'Asset-Mgmt'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Newbie',
    difficultyColor: 'primary',
    playgroundId: 'workit-landing',
    metrics: { duration: '3 days', complexity: 'Low', linesOfCode: 510 },
    files: [
      {
        name: 'landing.css',
        language: 'css',
        content: `.hero-visual {
  position: relative;
}
.bg-pattern {
  position: absolute;
  top: -10%;
  left: -20%;
  z-index: -1;
  pointer-events: none;
}`
      }
    ]
  },
  {
    id: 'nft-preview',
    title: 'NFT Preview Card',
    category: 'Newbie',
    description: 'Advanced hover effects using CSS pseudo-elements, custom overlays, and translucent borders.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCLgRcJPM8AoSehQgQanVAG3P7IT47BL6HrWKZrF4HukOs0w9OBU5I_PYIZFCUH7JWkgnhQo0YPKSN8rg_H84kmP5L5-HS-lESsM2uAtKKMM1kG-1vZ027TAi6OjfFNq488ilmGVutmEF8iH8Lq1zsr-UDF_sBBAF3S5R1GEorEq0ft4I1DNn8-lDi7yb-PNDW12_ysAcSpArti6Am6BQFl4ZxXj9FodHHVjTePqsD_nDMLsf3trctz',
    tags: ['CSS-Grid', 'Animations', 'Hover-Effects'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Newbie',
    difficultyColor: 'primary',
    playgroundId: 'nft-preview',
    metrics: { duration: '1 day', complexity: 'Low', linesOfCode: 180 },
    files: [
      {
        name: 'nft.css',
        language: 'css',
        content: `.image-overlay {
  position: absolute;
  inset: 0;
  background-color: rgba(0, 255, 240, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s ease;
}
.image-container:hover .image-overlay {
  opacity: 1;
}`
      }
    ]
  },
  
  // Junior Projects (12 requested in selector)
  {
    id: 'tip-calculator',
    title: 'Splitter Tip Calculator',
    category: 'Junior',
    description: 'A responsive tip calculator app parsing custom input values, active percentage selectors, and dynamic split calculations.',
    image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80',
    tags: ['React', 'Math', 'CSS-Grid'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Junior',
    difficultyColor: 'secondary',
    playgroundId: 'tip-calculator',
    metrics: { duration: '4 days', complexity: 'Medium', linesOfCode: 680 },
    files: [
      {
        name: 'TipCalculator.tsx',
        language: 'typescript',
        content: `export default function TipCalculator() {
  const [bill, setBill] = useState(0);
  const [tipPct, setTipPct] = useState(0.15);
  const [people, setPeople] = useState(1);
  
  const tipAmount = (bill * tipPct) / people;
  const totalAmount = (bill * (1 + tipPct)) / people;
  
  return (
    <div class="calculator-grid">...</div>
  );
}`
      }
    ]
  },
  {
    id: 'news-homepage',
    title: 'News Homepage',
    category: 'Junior',
    description: 'Multi-column layout utilizing CSS Grid & Flexbox, featuring a side sidebar drawer navigation for mobile and live-updating hero topics.',
    image: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=600&q=80',
    tags: ['HTML/CSS', 'Responsive', 'Grid'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Junior',
    difficultyColor: 'secondary',
    playgroundId: 'news-homepage',
    metrics: { duration: '3 days', complexity: 'Medium', linesOfCode: 420 },
    files: []
  },
  {
    id: 'advice-generator',
    title: 'Interactive Advice Generator',
    category: 'Junior',
    description: 'Real-time API integrations calling the Advice Slip API, styled with glowing drop shadows and responsive animations.',
    image: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=600&q=80',
    tags: ['API-Fetch', 'JS', 'Aesthetic'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Junior',
    difficultyColor: 'secondary',
    playgroundId: 'advice-generator',
    metrics: { duration: '2 days', complexity: 'Medium', linesOfCode: 290 },
    files: []
  },

  // Intermediate Projects (6 requested in selector)
  {
    id: 'todo-app',
    title: 'Todo App with Drag & Drop',
    category: 'Intermediate',
    description: 'Comprehensive task management system featuring drag-and-drop ordering, localStorage persistence, and multiple filter categories.',
    image: 'https://images.unsplash.com/photo-1540350394557-8d14678e7f91?auto=format&fit=crop&w=600&q=80',
    tags: ['Drag-Drop', 'Theme-Switcher', 'Storage'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Intermediate',
    difficultyColor: 'tertiary',
    playgroundId: 'todo-app',
    metrics: { duration: '6 days', complexity: 'High', linesOfCode: 1200 },
    files: [
      {
        name: 'TodoEngine.ts',
        language: 'typescript',
        content: `export function handleDragEnd(result: any, list: Todo[], setList: Function) {
  if (!result.destination) return;
  const items = Array.from(list);
  const [reorderedItem] = items.splice(result.source.index, 1);
  items.splice(result.destination.index, 0, reorderedItem);
  setList(items);
}`
      }
    ]
  },
  {
    id: 'countries-api',
    title: 'REST Countries Explorer',
    category: 'Intermediate',
    description: 'Beautiful multi-page layout integrating a REST API with client-side fuzzy searching, regional filtering, and dark/light toggle mode.',
    image: 'https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=600&q=80',
    tags: ['REST-API', 'Theme-Hook', 'Fuzzy-Search'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Intermediate',
    difficultyColor: 'tertiary',
    playgroundId: 'countries-api',
    metrics: { duration: '8 days', complexity: 'High', linesOfCode: 1450 },
    files: []
  },

  // Advanced Projects (4 requested in selector)
  {
    id: 'audiophile-ecommerce',
    title: 'Audiophile E-commerce Portal',
    category: 'Advanced',
    description: 'Fully featured multi-page online audio hardware store featuring a centralized cart state, complete checkout calculations, and high-fidelity page transitions.',
    image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=600&q=80',
    tags: ['React-State', 'Cart', 'Validation', 'Checkout'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Advanced',
    difficultyColor: 'error',
    playgroundId: 'audiophile',
    metrics: { duration: '15 days', complexity: 'Enterprise', linesOfCode: 4200 },
    files: [
      {
        name: 'CartContext.tsx',
        language: 'typescript',
        content: `export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  
  const addToCart = (product: Product, quantity: number) => {
    setCart(prev => {
      const exists = prev.find(item => item.id === product.id);
      if (exists) {
        return prev.map(item => item.id === product.id ? { ...item, qty: item.qty + quantity } : item);
      }
      return [...prev, { ...product, qty: quantity }];
    });
  };
};`
      }
    ]
  },
  {
    id: 'multistep-form',
    title: 'Interactive Multi-step Subscription',
    category: 'Advanced',
    description: 'Subscription builder flow with modular slide steps, pricing model selection, addon checklist, and summarized receipt review.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80',
    tags: ['Forms', 'Sub-Flow', 'Pricing-Engine'],
    isFeatured: false,
    liveUrl: '#',
    sourceUrl: '#',
    difficulty: 'Advanced',
    difficultyColor: 'error',
    playgroundId: 'multistep',
    metrics: { duration: '7 days', complexity: 'High', linesOfCode: 1800 },
    files: []
  }
];

export const SKILL_CATEGORIES = [
  {
    name: 'Frontend Core',
    skills: ['React', 'TypeScript', 'Next.js', 'Vue.js', 'HTML5 / CSS3'],
    level: 95
  },
  {
    name: 'CSS & Styling',
    skills: ['Tailwind CSS', 'Sass / SCSS', 'CSS Modules', 'Framer Motion'],
    level: 98
  },
  {
    name: 'Tooling & Testing',
    skills: ['Vite', 'Webpack', 'Jest', 'Cypress', 'Git / GitHub'],
    level: 88
  },
  {
    name: 'Architecture & State',
    skills: ['Zustand', 'Redux Toolkit', 'Clean Architecture', 'Monorepos', 'TDD'],
    level: 90
  }
];

export const EXPERIENCES: Experience[] = [
  {
    role: 'Senior Frontend Developer',
    company: 'Refined Labs',
    period: '2024 - Present',
    description: [
      'Architected high-performance monorepo with 15+ micro-frontend applications saving 40% dev setup overhead.',
      'Designed and deployed responsive and modular Design Systems utilizing Tailwind CSS and React 18+.',
      'Improved page speed metrics and Core Web Vitals by 35% through image caching, code-splitting, and server-side pre-rendering.'
    ],
    tags: ['React', 'Next.js', 'Monorepo', 'Core Web Vitals']
  },
  {
    role: 'Frontend Engineer',
    company: 'Symmetric Digital',
    period: '2022 - 2024',
    description: [
      'Developed 30+ interactive user dashboards using custom charting engines (d3, recharts) and client-authoritative state frameworks.',
      'Collaborated closely with visual designers to implement pixel-perfect, glassmorphic dark themes and complex spring transitions.',
      'Established full unit and integration test workflows with Cypress and Jest achieving 85% coverage.'
    ],
    tags: ['TypeScript', 'Tailwind', 'Recharts', 'Cypress']
  },
  {
    role: 'Junior Frontend UI Specialist',
    company: 'Pod Webmasters',
    period: '2020 - 2022',
    description: [
      'Built semantic HTML layouts, interactive forms, responsive landing pages, and access-restricted client sidebars.',
      'Maintained accessible elements aligned strictly with WCAG AAA standards and ARIA definitions.'
    ],
    tags: ['HTML5', 'Sass', 'Vanilla JS', 'Accessibility']
  }
];
