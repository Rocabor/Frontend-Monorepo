import React from 'react';
import { X, Briefcase, GraduationCap, MapPin, Mail, Globe, Sparkles, Award } from 'lucide-react';
import { EXPERIENCES, SKILL_CATEGORIES } from '../data';
import { motion } from 'motion/react';

interface ResumeModalProps {
  onClose: () => void;
}

export default function ResumeModal({ onClose }: ResumeModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-6 select-none">
      
      {/* Backdrop overlay */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-[#070a0d]/90 backdrop-blur-md cursor-pointer"
      />

      {/* Main Glass Modal Window */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-3xl max-h-[85vh] bg-surface-container border border-white/10 rounded-2xl overflow-hidden flex flex-col shadow-2xl z-10 select-text"
      >
        {/* Header bar */}
        <div className="flex justify-between items-center px-6 py-4 bg-surface-container-high border-b border-white/5">
          <div className="flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-primary" />
            <span className="font-display font-bold text-sm tracking-tight text-on-surface">Interactive Developer Log & Resume</span>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/5 text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal body scroll container */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8">
          
          {/* Resume Header Panel */}
          <div className="space-y-4 text-center md:text-left md:flex justify-between items-start gap-4">
            <div className="space-y-1.5">
              <h3 className="font-display font-bold text-2xl text-on-surface tracking-tight tech-gradient">
                Roberto Borges Jimez
              </h3>
              <p className="font-display font-semibold text-sm text-primary">
                Senior Frontend & UI Systems Architect
              </p>
              <div className="flex flex-wrap justify-center md:justify-start gap-3 pt-2 text-xs text-on-surface-variant font-mono">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" /> San Francisco, CA
                </span>
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5" /> robertoborgesjimez@gmail.com
                </span>
              </div>
            </div>

            <div className="text-center md:text-right pt-4 md:pt-0">
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-primary/10 border border-primary/20 text-primary rounded-full text-[11px] font-mono">
                <Award className="w-3.5 h-3.5" /> OPEN TO ROLE COGNITIONS
              </span>
            </div>
          </div>

          <hr className="border-white/5" />

          {/* Core Layout Split */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            
            {/* Timeline Experience (Col span 3) */}
            <div className="md:col-span-3 space-y-5">
              <h4 className="text-xs font-mono tracking-widest text-on-surface-variant uppercase flex items-center gap-2 pb-2 border-b border-white/5">
                <Briefcase className="w-4 h-4 text-secondary" /> WORK EXPERIENCE
              </h4>

              <div className="space-y-6 pl-1.5 border-l border-white/10 ml-2">
                {EXPERIENCES.map((exp, idx) => (
                  <div key={idx} className="relative pl-5 space-y-2">
                    <span className="absolute -left-[24px] top-1 w-2 h-2 rounded-full bg-primary ring-4 ring-primary/20"></span>
                    <div className="space-y-0.5">
                      <h5 className="font-display font-bold text-xs md:text-sm text-on-surface">{exp.role}</h5>
                      <div className="flex justify-between items-center text-xs font-mono text-on-surface-variant">
                        <span>{exp.company}</span>
                        <span>{exp.period}</span>
                      </div>
                    </div>
                    <ul className="list-disc list-outside pl-4 space-y-1 text-xs text-on-surface-variant leading-relaxed">
                      {exp.description.map((desc, dIdx) => (
                        <li key={dIdx}>{desc}</li>
                      ))}
                    </ul>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {exp.tags.map(tag => (
                        <span key={tag} className="text-[9px] font-mono bg-white/5 text-on-surface-variant px-2 py-0.5 rounded">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Core Skills Graph (Col span 2) */}
            <div className="md:col-span-2 space-y-5">
              <h4 className="text-xs font-mono tracking-widest text-on-surface-variant uppercase flex items-center gap-2 pb-2 border-b border-white/5">
                <Sparkles className="w-4 h-4 text-tertiary" /> CORE EXPERTISE
              </h4>

              <div className="space-y-4">
                {SKILL_CATEGORIES.map((cat, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-on-surface font-semibold">{cat.name}</span>
                      <span className="text-primary font-bold">{cat.level}%</span>
                    </div>
                    {/* Progress bar */}
                    <div className="w-full h-1.5 bg-surface-container-highest rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-primary to-secondary rounded-full"
                        style={{ width: `${cat.level}%` }}
                      ></div>
                    </div>
                    <div className="flex flex-wrap gap-1 text-[10px] font-mono text-on-surface-variant">
                      {cat.skills.join(' • ')}
                    </div>
                  </div>
                ))}
              </div>

              {/* Education section */}
              <div className="pt-4 space-y-3">
                <h4 className="text-xs font-mono tracking-widest text-on-surface-variant uppercase flex items-center gap-2 pb-2 border-b border-white/5">
                  <GraduationCap className="w-4 h-4 text-emerald-400" /> ACADEMICS
                </h4>
                <div className="space-y-1 text-xs">
                  <h5 className="font-display font-semibold text-on-surface">B.S. Software Engineering</h5>
                  <p className="text-on-surface-variant">University of California, Berkeley</p>
                  <span className="text-[10px] font-mono text-on-surface-variant/70">Class of 2020</span>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Footer info bar */}
        <div className="px-6 py-3 bg-surface-container-high border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-on-surface-variant">
          <span className="flex items-center gap-1">
            <Globe className="w-3.5 h-3.5 text-primary" />
            LIVE VERIFIABLE DATA PORTFOLIO
          </span>
          <span>STABLE VERSION</span>
        </div>

      </motion.div>
    </div>
  );
}
