import React, { useState } from 'react';
import { Folder, FolderOpen, FileCode, Check, Terminal, Code } from 'lucide-react';
import { Project } from '../types';

interface MonorepoExplorerProps {
  projects: Project[];
  onSelectProject: (p: Project) => void;
}

export default function MonorepoExplorer({ projects, onSelectProject }: MonorepoExplorerProps) {
  const [selectedFile, setSelectedFile] = useState<{ pId: string; fIdx: number } | null>({
    pId: 'intro-signup',
    fIdx: 0,
  });

  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    root: true,
    packages: true,
    challenges: true,
    newbie: true,
    junior: false,
  });

  const toggleFolder = (key: string) => {
    setExpandedFolders((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Find the selected file's content
  const activeProj = projects.find((p) => p.id === selectedFile?.pId) || projects[0];
  const activeFile = activeProj?.files?.[selectedFile?.fIdx || 0] || {
    name: 'readme.md',
    language: 'markdown',
    content: `# Refined Portfolio Monorepo\n\nClick on any challenge's code files to inspect the clean layouts, accessibility practices, and state logic implementation.`,
  };

  const handleFileClick = (pId: string, fIdx: number) => {
    setSelectedFile({ pId, fIdx });
    const proj = projects.find((p) => p.id === pId);
    if (proj) {
      onSelectProject(proj);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 border border-white/5 rounded-2xl bg-surface-container-low overflow-hidden">
      
      {/* File Tree Sidebar */}
      <div className="lg:col-span-1 border-r border-white/5 bg-surface-container-lowest p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-primary" />
            <span className="font-display font-bold text-sm tracking-tight">Monorepo Workspace</span>
          </div>
          <span className="text-[10px] font-mono text-on-surface-variant bg-white/5 px-2 py-0.5 rounded">
            v1.2.0
          </span>
        </div>

        {/* Tree List */}
        <div className="space-y-1.5 text-xs font-mono select-none">
          {/* Root directory */}
          <div>
            <div
              onClick={() => toggleFolder('root')}
              className="flex items-center gap-2 py-1 px-2 hover:bg-white/5 rounded cursor-pointer text-primary"
            >
              {expandedFolders.root ? <FolderOpen className="w-4 h-4" /> : <Folder className="w-4 h-4" />}
              <span>monorepo-root /</span>
            </div>

            {expandedFolders.root && (
              <div className="pl-4 border-l border-white/10 ml-3.5 space-y-1 py-1">
                {/* Packages Folder */}
                <div>
                  <div
                    onClick={() => toggleFolder('packages')}
                    className="flex items-center gap-2 py-1 px-2 hover:bg-white/5 rounded cursor-pointer text-secondary"
                  >
                    {expandedFolders.packages ? <FolderOpen className="w-3.5 h-3.5" /> : <Folder className="w-3.5 h-3.5" />}
                    <span>packages /</span>
                  </div>
                  {expandedFolders.packages && (
                    <div className="pl-4 border-l border-white/10 ml-3 py-1 space-y-1">
                      <div className="flex items-center gap-1.5 py-1 px-2 hover:bg-white/5 rounded text-on-surface-variant">
                        <FileCode className="w-3.5 h-3.5" />
                        <span>ui-components/</span>
                      </div>
                      <div className="flex items-center gap-1.5 py-1 px-2 hover:bg-white/5 rounded text-on-surface-variant">
                        <FileCode className="w-3.5 h-3.5" />
                        <span>theme-engine/</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Challenges Folder */}
                <div>
                  <div
                    onClick={() => toggleFolder('challenges')}
                    className="flex items-center gap-2 py-1 px-2 hover:bg-white/5 rounded cursor-pointer text-tertiary"
                  >
                    {expandedFolders.challenges ? <FolderOpen className="w-3.5 h-3.5" /> : <Folder className="w-3.5 h-3.5" />}
                    <span>challenges /</span>
                  </div>

                  {expandedFolders.challenges && (
                    <div className="pl-4 border-l border-white/10 ml-3 py-1 space-y-1.5">
                      
                      {/* Newbie subfolder */}
                      <div>
                        <div
                          onClick={() => toggleFolder('newbie')}
                          className="flex items-center gap-2 py-1 px-2 hover:bg-white/5 rounded cursor-pointer text-primary"
                        >
                          {expandedFolders.newbie ? <FolderOpen className="w-3.5 h-3.5" /> : <Folder className="w-3.5 h-3.5" />}
                          <span>newbie /</span>
                        </div>

                        {expandedFolders.newbie && (
                          <div className="pl-4 border-l border-white/10 ml-3 py-1 space-y-1">
                            {projects
                              .filter((p) => p.category === 'Newbie' && p.files.length > 0)
                              .map((p) => (
                                <div key={p.id} className="space-y-0.5">
                                  <div className="text-[11px] text-on-surface/80 py-0.5 px-2 font-semibold flex items-center gap-1">
                                    <Folder className="w-3 h-3 text-primary-container" />
                                    <span>{p.id} /</span>
                                  </div>
                                  <div className="pl-3.5 space-y-0.5">
                                    {p.files.map((file, fIdx) => {
                                      const isSelected = selectedFile?.pId === p.id && selectedFile?.fIdx === fIdx;
                                      return (
                                        <div
                                          key={file.name}
                                          onClick={() => handleFileClick(p.id, fIdx)}
                                          className={`flex items-center gap-1.5 py-0.5 px-2 rounded cursor-pointer transition-colors ${
                                            isSelected
                                              ? 'bg-primary/15 text-primary border-l-2 border-primary font-bold'
                                              : 'text-on-surface-variant hover:bg-white/5'
                                          }`}
                                        >
                                          <Code className="w-3 h-3 text-on-surface-variant/50" />
                                          <span>{file.name}</span>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              ))}
                          </div>
                        )}
                      </div>

                      {/* Junior subfolder */}
                      <div>
                        <div
                          onClick={() => toggleFolder('junior')}
                          className="flex items-center gap-2 py-1 px-2 hover:bg-white/5 rounded cursor-pointer text-secondary"
                        >
                          {expandedFolders.junior ? <FolderOpen className="w-3.5 h-3.5" /> : <Folder className="w-3.5 h-3.5" />}
                          <span>junior /</span>
                        </div>

                        {expandedFolders.junior && (
                          <div className="pl-4 border-l border-white/10 ml-3 py-1 space-y-1">
                            {projects
                              .filter((p) => p.category === 'Junior' && p.files.length > 0)
                              .map((p) => (
                                <div key={p.id} className="space-y-0.5">
                                  <div className="text-[11px] text-on-surface/80 py-0.5 px-2 font-semibold flex items-center gap-1">
                                    <Folder className="w-3 h-3 text-secondary" />
                                    <span>{p.id} /</span>
                                  </div>
                                  <div className="pl-3.5 space-y-0.5">
                                    {p.files.map((file, fIdx) => {
                                      const isSelected = selectedFile?.pId === p.id && selectedFile?.fIdx === fIdx;
                                      return (
                                        <div
                                          key={file.name}
                                          onClick={() => handleFileClick(p.id, fIdx)}
                                          className={`flex items-center gap-1.5 py-0.5 px-2 rounded cursor-pointer transition-colors ${
                                            isSelected
                                              ? 'bg-secondary/15 text-secondary border-l-2 border-secondary font-bold'
                                              : 'text-on-surface-variant hover:bg-white/5'
                                          }`}
                                        >
                                          <Code className="w-3 h-3 text-on-surface-variant/50" />
                                          <span>{file.name}</span>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              ))}
                          </div>
                        )}
                      </div>

                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1.5 py-1 px-2 hover:bg-white/5 rounded text-on-surface-variant">
                  <FileCode className="w-3.5 h-3.5" />
                  <span>package.json</span>
                </div>
                <div className="flex items-center gap-1.5 py-1 px-2 hover:bg-white/5 rounded text-on-surface-variant">
                  <FileCode className="w-3.5 h-3.5" />
                  <span>tsconfig.json</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Code Editor Panel */}
      <div className="lg:col-span-2 flex flex-col bg-surface-container-lowest overflow-hidden h-[420px] lg:h-auto">
        <div className="flex items-center justify-between px-4 py-2 bg-surface-container-high border-b border-white/5 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/50"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-green-500/50"></span>
            <span className="text-on-surface-variant text-[11px] ml-2 font-bold">{activeFile.name}</span>
          </div>
          <span className="text-primary text-[10px] uppercase font-bold tracking-wider">{activeFile.language}</span>
        </div>

        {/* Real formatted snippet display */}
        <div className="flex-1 overflow-auto p-4 bg-[#0a0f12] font-mono text-xs leading-relaxed text-on-surface-variant select-text">
          <pre className="text-[11px] text-emerald-400">
            {activeFile.content}
          </pre>
        </div>

        <div className="px-4 py-2 bg-surface-container-high border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-on-surface-variant">
          <span>Target: {activeProj?.title}</span>
          <div className="flex items-center gap-1 text-primary">
            <Check className="w-3 h-3" />
            <span>ESTABLISHED</span>
          </div>
        </div>
      </div>

    </div>
  );
}
