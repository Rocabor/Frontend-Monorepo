import React from 'react';
import { X, Play, Code, CheckCircle, ArrowRight, Sparkles, AlertCircle } from 'lucide-react';
import { Project } from '../types';
import InteractivePreview from './InteractivePreview';
import { motion } from 'motion/react';

interface ProjectDetailModalProps {
  project: Project;
  onClose: () => void;
}

export default function ProjectDetailModal({ project, onClose }: ProjectDetailModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-6 select-none">
      
      {/* Backdrop overlay */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-[#070a0d]/90 backdrop-blur-md cursor-pointer"
      />

      {/* Main Glass Modal Window */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-4xl max-h-[90vh] bg-surface-container border border-white/10 rounded-2xl overflow-hidden flex flex-col shadow-2xl z-10 select-text"
      >
        {/* Header bar */}
        <div className="flex justify-between items-center px-6 py-4 bg-surface-container-high border-b border-white/5">
          <div className="flex items-center gap-3">
            <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold border ${
              project.category === 'Newbie' ? 'bg-primary/10 text-primary border-primary/20' :
              project.category === 'Junior' ? 'bg-secondary/10 text-secondary border-secondary/20' :
              project.category === 'Intermediate' ? 'bg-tertiary/10 text-tertiary border-tertiary/20' :
              'bg-error/10 text-error border-error/20'
            }`}>
              {project.category}
            </span>
            <h3 className="font-display font-bold text-base md:text-lg text-on-surface tracking-tight">
              {project.title}
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/5 text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal body scroll container */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          
          {/* Top Banner / Metrics split */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 relative aspect-video rounded-xl overflow-hidden bg-slate-950 border border-white/5">
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f12] to-transparent"></div>
            </div>

            {/* Tech Metrics Box */}
            <div className="glass-card p-5 rounded-xl space-y-4 flex flex-col justify-center">
              <h4 className="text-xs font-mono tracking-widest text-on-surface-variant uppercase border-b border-white/5 pb-2">
                PROJECT METRICS
              </h4>
              <div className="space-y-3 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-on-surface-variant">Complexity:</span>
                  <span className="text-primary font-bold">{project.metrics.complexity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-on-surface-variant">Build Duration:</span>
                  <span className="text-secondary font-bold">{project.metrics.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-on-surface-variant">Lines of Code:</span>
                  <span className="text-tertiary font-bold">{project.metrics.linesOfCode} lines</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 pt-2">
                {project.tags.map(tag => (
                  <span key={tag} className="text-[9px] font-mono bg-white/5 text-on-surface-variant/80 px-2 py-0.5 rounded border border-white/5">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Interactive Playgrounds and Solutions split */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Interactive Widget Playground Panel */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Play className="w-4 h-4 text-primary" />
                <h4 className="font-display font-semibold text-sm text-on-surface">Interactive Sandbox Demo</h4>
              </div>
              <InteractivePreview playgroundId={project.playgroundId || project.id} />
            </div>

            {/* Details & Architecture Takeaway Panel */}
            <div className="space-y-5 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Code className="w-4 h-4 text-secondary" />
                  <h4 className="font-display font-semibold text-sm text-on-surface">Architectural Log</h4>
                </div>
                <p className="text-xs md:text-sm text-on-surface-variant leading-relaxed">
                  {project.description}
                </p>

                {/* Key focus takeaways list */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-start gap-2.5 text-xs text-on-surface-variant">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Responsive Layout alignment verified across viewport presets.</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-on-surface-variant">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Semantic accessibility hierarchy supporting standard screen-readers.</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-on-surface-variant">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Fully tested interactive inputs utilizing advanced state validation cycles.</span>
                  </div>
                </div>
              </div>

              {/* CTAs */}
              <div className="flex gap-3 pt-4 border-t border-white/5">
                <a 
                  href={project.liveUrl}
                  className="flex-1 bg-primary text-on-primary text-center font-display font-semibold text-xs py-2.5 rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  Live Preview <ArrowRight className="w-3.5 h-3.5" />
                </a>
                <a 
                  href={project.sourceUrl}
                  className="flex-1 border border-white/10 text-on-surface text-center font-display font-semibold text-xs py-2.5 rounded-lg hover:bg-white/5 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Code className="w-3.5 h-3.5" /> Source Code
                </a>
              </div>
            </div>

          </div>

        </div>

        {/* Footer info bar */}
        <div className="px-6 py-3 bg-surface-container-high border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-on-surface-variant">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-tertiary" />
            STRICTLY ALIGNED TO STYLE MANDATES
          </span>
          <span>EST. COGNITIVE LEVEL: SENIOR LOG</span>
        </div>

      </motion.div>
    </div>
  );
}
