import React, { useState } from 'react';
import { Star, Check, AlertCircle, Sparkles, Send, Play, Terminal, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface InteractivePreviewProps {
  playgroundId: string;
}

export default function InteractivePreview({ playgroundId }: InteractivePreviewProps) {
  // 1. Rating Component States
  const [rating, setRating] = useState<number | null>(null);
  const [submittedRating, setSubmittedRating] = useState(false);

  // 2. FAQ Accordion States
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const faqs = [
    { q: "How does this portfolio work?", a: "This is a reactive React application simulating my development history. You can filter challenges and interact with live simulations directly on this dashboard!" },
    { q: "What technologies are used in these projects?", a: "The foundational levels are built with semantic HTML, CSS Grid/Flexbox, and vanilla JS. Junior and above introduce TypeScript, React, and modular architectures." },
    { q: "Is the source code of these projects real?", a: "Yes! Every single project corresponds to a real public repository of my Frontend Mentor solutions." }
  ];

  // 3. Pod Request States
  const [podEmail, setPodEmail] = useState('');
  const [podError, setPodError] = useState('');
  const [podSuccess, setPodSuccess] = useState(false);

  // 4. Intro Component Form States
  const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '', password: '' });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [formSuccess, setFormSuccess] = useState(false);

  // 5. NFT Card Interactive States
  const [nftLiked, setNftLiked] = useState(false);
  const [bidPrice, setBidPrice] = useState(1.48);

  // 6. Workit landing dynamic scale state
  const [growthLevel, setGrowthLevel] = useState(1); // 1 to 4 (Newbie, Junior, Intermediate, Advanced)

  // 7. Tip Calculator states
  const [bill, setBill] = useState(145.50);
  const [tipPercent, setTipPercent] = useState(15);
  const [people, setPeople] = useState(3);

  // Handlers
  const handlePodSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!podEmail || !podEmail.includes('@')) {
      setPodError('Please insert a valid email address');
      setPodSuccess(false);
    } else {
      setPodError('');
      setPodSuccess(true);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    if (!formData.firstName.trim()) errors.firstName = 'First Name cannot be empty';
    if (!formData.lastName.trim()) errors.lastName = 'Last Name cannot be empty';
    if (!formData.email.includes('@')) errors.email = 'Looks like this is not an email';
    if (formData.password.length < 6) errors.password = 'Password must be at least 6 characters';

    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setFormSuccess(true);
    }
  };

  return (
    <div className="w-full h-full min-h-[380px] bg-surface-container-low border border-white/5 rounded-xl p-6 flex flex-col justify-center">
      <AnimatePresence mode="wait">
        
        {/* RATING PLAYGROUND */}
        {playgroundId === 'rating-component' && (
          <motion.div
            key="rating"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="max-w-xs mx-auto text-center"
          >
            {!submittedRating ? (
              <div className="space-y-5">
                <div className="w-10 h-10 bg-surface-container-highest rounded-full flex items-center justify-center mx-auto text-tertiary">
                  <Star className="w-5 h-5 fill-current" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-lg font-display font-semibold text-on-surface">How was your experience?</h4>
                  <p className="text-xs text-on-surface-variant leading-relaxed">
                    Please let us know how we did with our support request. All feedback is appreciated!
                  </p>
                </div>
                <div className="flex justify-between gap-2 max-w-[240px] mx-auto">
                  {[1, 2, 3, 4, 5].map((val) => (
                    <button
                      key={val}
                      onClick={() => setRating(val)}
                      className={`w-10 h-10 rounded-full font-mono text-xs transition-all ${
                        rating === val
                          ? 'bg-primary text-on-primary font-bold scale-110 shadow-lg shadow-primary/20'
                          : 'bg-surface-container-highest text-on-surface-variant hover:bg-white/10'
                      }`}
                    >
                      {val}
                    </button>
                  ))}
                </div>
                <button
                  disabled={rating === null}
                  onClick={() => setSubmittedRating(true)}
                  className="w-full bg-primary hover:bg-primary-container text-on-primary font-display font-semibold text-xs uppercase tracking-wider py-3 rounded-full transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Submit Rating
                </button>
              </div>
            ) : (
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="space-y-4 py-4"
              >
                <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <span className="inline-block bg-white/5 border border-white/10 text-primary text-[10px] font-mono px-3 py-1 rounded-full">
                  You selected {rating} out of 5
                </span>
                <div className="space-y-2">
                  <h4 className="text-lg font-display font-semibold text-on-surface">Thank You!</h4>
                  <p className="text-xs text-on-surface-variant leading-relaxed">
                    We appreciate you taking the time to give a rating. If you ever need more support, don't hesitate to reach out!
                  </p>
                </div>
                <button
                  onClick={() => {
                    setSubmittedRating(false);
                    setRating(null);
                  }}
                  className="text-xs text-primary hover:underline font-medium"
                >
                  Rate Again
                </button>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* FAQ ACCORDION */}
        {playgroundId === 'faq-accordion' && (
          <motion.div
            key="faq"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-4 max-w-md mx-auto w-full"
          >
            <div className="flex items-center gap-2 mb-4 justify-center">
              <HelpCircle className="w-5 h-5 text-tertiary" />
              <h4 className="font-display font-bold text-on-surface">Frequently Asked Questions</h4>
            </div>
            <div className="space-y-2">
              {faqs.map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div
                    key={idx}
                    className="border border-white/5 rounded-lg bg-surface-container-high overflow-hidden"
                  >
                    <button
                      onClick={() => setOpenFaq(isOpen ? null : idx)}
                      className="w-full flex justify-between items-center p-4 text-left hover:bg-white/5 transition-colors"
                    >
                      <span className="text-xs font-semibold text-on-surface font-display">{faq.q}</span>
                      <span className={`text-lg font-mono text-primary transition-transform duration-300 ${isOpen ? 'rotate-45' : ''}`}>
                        +
                      </span>
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden bg-surface-container-highest"
                        >
                          <p className="p-4 text-xs text-on-surface-variant leading-relaxed border-t border-white/5">
                            {faq.a}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* POD REQUEST ACCESS */}
        {playgroundId === 'pod-request' && (
          <motion.div
            key="pod"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="max-w-sm mx-auto text-center space-y-5 w-full"
          >
            <div className="space-y-2">
              <span className="text-[10px] font-mono tracking-widest text-primary uppercase bg-primary/10 border border-primary/20 px-3 py-1 rounded-full">
                PODCAST NETWORK
              </span>
              <h4 className="text-xl font-display font-bold text-on-surface">Request Early Access</h4>
              <p className="text-xs text-on-surface-variant leading-relaxed">
                Join our premium network of creators and listeners. Input your corporate email to get a personalized beta entry link.
              </p>
            </div>

            {!podSuccess ? (
              <form onSubmit={handlePodSubmit} className="space-y-3">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Email address"
                    value={podEmail}
                    onChange={(e) => {
                      setPodEmail(e.target.value);
                      if (podError) setPodError('');
                    }}
                    className={`w-full bg-surface-container-highest border text-xs px-4 py-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-primary ${
                      podError ? 'border-red-500 text-red-300' : 'border-white/10 text-on-surface'
                    }`}
                  />
                  {podError && (
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 text-red-500">
                      <AlertCircle className="w-4 h-4" />
                    </div>
                  )}
                </div>
                {podError && (
                  <p className="text-[11px] text-red-400 text-left pl-1">{podError}</p>
                )}
                <button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary-container text-on-primary font-semibold text-xs py-3 rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" /> Request Access
                </button>
              </form>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-5 border border-emerald-500/20 bg-emerald-500/5 rounded-xl space-y-3 text-center"
              >
                <div className="w-10 h-10 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <Check className="w-5 h-5" />
                </div>
                <h5 className="text-sm font-semibold text-on-surface font-display">Invitation Queued!</h5>
                <p className="text-xs text-on-surface-variant">
                  We sent a confirmation voucher to <strong className="text-on-surface">{podEmail}</strong>. Welcome aboard!
                </p>
                <button
                  onClick={() => {
                    setPodSuccess(false);
                    setPodEmail('');
                  }}
                  className="text-xs text-primary hover:underline pt-2 font-medium"
                >
                  Request another email
                </button>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* INTRO COMPONENT WITH SIGNUP FORM */}
        {playgroundId === 'intro-signup' && (
          <motion.div
            key="signup"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="max-w-md mx-auto w-full space-y-4"
          >
            <div className="bg-secondary-container text-on-secondary-container rounded-lg p-3 text-center border border-white/5">
              <p className="text-[11px] font-medium font-display">
                <strong>Try it free 7 days</strong> then $20/mo. thereafter
              </p>
            </div>

            {!formSuccess ? (
              <form onSubmit={handleFormSubmit} className="bg-surface-container-high border border-white/5 rounded-xl p-5 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <input
                      type="text"
                      placeholder="First Name"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className={`w-full bg-surface-container-highest border text-xs px-3 py-2.5 rounded-md focus:outline-none ${
                        formErrors.firstName ? 'border-red-500 text-red-200' : 'border-white/5'
                      }`}
                    />
                    {formErrors.firstName && (
                      <span className="text-[10px] text-red-400">{formErrors.firstName}</span>
                    )}
                  </div>

                  <div className="space-y-1">
                    <input
                      type="text"
                      placeholder="Last Name"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      className={`w-full bg-surface-container-highest border text-xs px-3 py-2.5 rounded-md focus:outline-none ${
                        formErrors.lastName ? 'border-red-500 text-red-200' : 'border-white/5'
                      }`}
                    />
                    {formErrors.lastName && (
                      <span className="text-[10px] text-red-400">{formErrors.lastName}</span>
                    )}
                  </div>
                </div>

                <div className="space-y-1">
                  <input
                    type="text"
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`w-full bg-surface-container-highest border text-xs px-3 py-2.5 rounded-md focus:outline-none ${
                      formErrors.email ? 'border-red-500 text-red-200' : 'border-white/5'
                    }`}
                  />
                  {formErrors.email && (
                    <span className="text-[10px] text-red-400">{formErrors.email}</span>
                  )}
                </div>

                <div className="space-y-1">
                  <input
                    type="password"
                    placeholder="Password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={`w-full bg-surface-container-highest border text-xs px-3 py-2.5 rounded-md focus:outline-none ${
                      formErrors.password ? 'border-red-500 text-red-200' : 'border-white/5'
                    }`}
                  />
                  {formErrors.password && (
                    <span className="text-[10px] text-red-400">{formErrors.password}</span>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs uppercase tracking-wider py-3 rounded-md transition-all shadow-md shadow-emerald-500/15"
                >
                  Claim your free trial
                </button>
                <p className="text-[9px] text-center text-on-surface-variant leading-relaxed">
                  By clicking the button, you are agreeing to our <span className="text-secondary cursor-pointer hover:underline">Terms and Services</span>.
                </p>
              </form>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl p-6 text-center space-y-3"
              >
                <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h5 className="font-display font-bold text-base text-on-surface">Free Trial Activated!</h5>
                <p className="text-xs text-on-surface-variant">
                  Awesome! We have set up your premium educational trial. Logins have been emailed to: <br />
                  <strong className="text-on-surface">{formData.email}</strong>
                </p>
                <button
                  onClick={() => {
                    setFormSuccess(false);
                    setFormData({ firstName: '', lastName: '', email: '', password: '' });
                    setFormErrors({});
                  }}
                  className="text-xs text-primary hover:underline font-semibold"
                >
                  Reset Form Mock
                </button>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* NFT PREVIEW HOLOGRAPHIC CARD */}
        {playgroundId === 'nft-preview' && (
          <motion.div
            key="nft"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="max-w-[240px] mx-auto bg-surface-container-high border border-white/5 rounded-xl p-4 space-y-3 shadow-2xl relative overflow-hidden group"
          >
            {/* Image Overlay logic simulated */}
            <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-slate-800">
              <img
                src="https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&w=300&q=80"
                alt="NFT artwork"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-primary/20 backdrop-blur-[1px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="bg-surface-container p-2.5 rounded-full text-primary border border-primary/20 scale-90 group-hover:scale-100 transition-all duration-300">
                  <Sparkles className="w-5 h-5 fill-current" />
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <h5 className="font-display font-bold text-sm text-on-surface hover:text-primary cursor-pointer transition-colors">
                Equilibrium #3429
              </h5>
              <p className="text-[11px] text-on-surface-variant leading-relaxed">
                Our Equilibrium collection promotes balance and absolute tranquility.
              </p>
            </div>

            <div className="flex justify-between items-center text-xs font-mono border-b border-white/5 pb-3">
              <div className="flex items-center gap-1.5 text-primary font-bold">
                <span className="text-[10px]">ETH</span>
                <span>{bidPrice.toFixed(2)}</span>
              </div>
              <div className="text-on-surface-variant flex items-center gap-1">
                <span>3 days left</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full overflow-hidden border border-white/10 bg-slate-700">
                  <div className="w-full h-full bg-gradient-to-br from-tertiary to-secondary"></div>
                </div>
                <span className="text-[10px] text-on-surface-variant">
                  Creation of <strong className="text-on-surface hover:text-primary cursor-pointer">Jules Wyvern</strong>
                </span>
              </div>

              <button
                onClick={() => {
                  setNftLiked(!nftLiked);
                  setBidPrice(prev => nftLiked ? prev - 0.05 : prev + 0.05);
                }}
                className={`p-1.5 rounded-full transition-all ${
                  nftLiked ? 'bg-red-500/10 text-red-400' : 'text-on-surface-variant hover:bg-white/5'
                }`}
              >
                <Star className={`w-3.5 h-3.5 ${nftLiked ? 'fill-current' : ''}`} />
              </button>
            </div>
          </motion.div>
        )}

        {/* WORKIT LANDING GROWING GRAPH */}
        {playgroundId === 'workit-landing' && (
          <motion.div
            key="workit"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-5 max-w-md mx-auto w-full text-center"
          >
            <div className="space-y-1">
              <span className="text-[9px] font-mono tracking-widest text-tertiary bg-tertiary/10 border border-tertiary/20 px-2.5 py-0.5 rounded-full">
                SCALE SYSTEM
              </span>
              <h4 className="text-lg font-display font-bold text-on-surface">Architecting Engineer Growth</h4>
              <p className="text-xs text-on-surface-variant">
                Adjust the timeline to see how code density and pattern optimization evolve together.
              </p>
            </div>

            <div className="bg-surface-container-high border border-white/5 rounded-xl p-5 space-y-4 text-left">
              <div className="flex justify-between items-center text-xs font-mono text-on-surface-variant">
                <span>CURRENT PHASE:</span>
                <span className="text-primary font-bold">
                  {growthLevel === 1 && '1. Foundations (Newbie)'}
                  {growthLevel === 2 && '2. Layouts & APIs (Junior)'}
                  {growthLevel === 3 && '3. Architectures (Intermediate)'}
                  {growthLevel === 4 && '4. Enterprise Systems (Advanced)'}
                </span>
              </div>

              {/* Custom interactive graph */}
              <div className="h-20 flex items-end gap-2 bg-black/10 rounded-lg p-2 border border-white/5 overflow-hidden">
                {[...Array(12)].map((_, i) => {
                  const factor = Math.min(i + 1, growthLevel * 3);
                  const h = factor * 5 + 10;
                  return (
                    <motion.div
                      key={i}
                      initial={{ height: 10 }}
                      animate={{ height: `${h}%` }}
                      className={`flex-1 rounded-t-sm transition-all duration-300 ${
                        i % 3 === 0 ? 'bg-primary' : i % 3 === 1 ? 'bg-secondary' : 'bg-tertiary'
                      }`}
                    ></motion.div>
                  );
                })}
              </div>

              {/* Slider selector */}
              <div className="space-y-2">
                <input
                  type="range"
                  min="1"
                  max="4"
                  value={growthLevel}
                  onChange={(e) => setGrowthLevel(parseInt(e.target.value))}
                  className="w-full h-1 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
                />
                <div className="flex justify-between text-[9px] font-mono text-on-surface-variant px-1">
                  <span>NEWBIE</span>
                  <span>JUNIOR</span>
                  <span>INTERMEDIATE</span>
                  <span>ADVANCED</span>
                </div>
              </div>

              <div className="text-xs text-on-surface-variant bg-black/10 p-3 rounded-lg border border-white/5 font-mono">
                {growthLevel === 1 && 'HTML, Flexbox, Static CSS. Focus on responsive, accessible documents.'}
                {growthLevel === 2 && 'React, API integrations, Fetch loops, Client side sorting/filters.'}
                {growthLevel === 3 && 'Complex state managers, custom D3 chart elements, modular routers.'}
                {growthLevel === 4 && 'Multi-step micro-frontends, monorepo architecture, Web3 logic interfaces.'}
              </div>
            </div>
          </motion.div>
        )}

        {/* DEFAULT FALLBACK - TIP CALCULATOR (For Junior and above) */}
        {playgroundId === 'tip-calculator' && (
          <motion.div
            key="tip"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="max-w-md mx-auto w-full space-y-4"
          >
            <div className="text-center space-y-1">
              <span className="text-[10px] font-mono tracking-widest text-secondary uppercase bg-secondary/10 border border-secondary/20 px-3 py-1 rounded-full">
                SPLITTER CALCULATOR
              </span>
              <h4 className="font-display font-semibold text-base text-on-surface">Interactive Calculations</h4>
            </div>

            <div className="bg-surface-container-high border border-white/5 rounded-xl p-5 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-on-surface-variant">BILL ($)</label>
                  <input
                    type="number"
                    value={bill}
                    onChange={(e) => setBill(parseFloat(e.target.value) || 0)}
                    className="w-full bg-surface-container-highest border border-white/5 text-xs p-2 rounded focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-on-surface-variant">PEOPLE</label>
                  <input
                    type="number"
                    min="1"
                    value={people}
                    onChange={(e) => setPeople(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full bg-surface-container-highest border border-white/5 text-xs p-2 rounded focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-on-surface-variant">SELECT TIP: {tipPercent}%</label>
                <div className="grid grid-cols-4 gap-2">
                  {[5, 10, 15, 20].map((pct) => (
                    <button
                      key={pct}
                      onClick={() => setTipPercent(pct)}
                      className={`text-xs p-2 rounded font-mono ${
                        tipPercent === pct ? 'bg-primary text-on-primary font-bold' : 'bg-surface-container-highest text-on-surface-variant hover:bg-white/5'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-black/10 border border-white/5 rounded-lg p-3 flex justify-between items-center text-xs">
                <div className="space-y-1">
                  <span className="text-on-surface font-semibold font-display">Tip Amount</span>
                  <span className="block text-[10px] text-on-surface-variant">/ person</span>
                </div>
                <span className="text-primary font-mono font-bold text-lg">
                  ${((bill * (tipPercent / 100)) / people).toFixed(2)}
                </span>
              </div>

              <div className="bg-black/10 border border-white/5 rounded-lg p-3 flex justify-between items-center text-xs">
                <div className="space-y-1">
                  <span className="text-on-surface font-semibold font-display">Total Bill</span>
                  <span className="block text-[10px] text-on-surface-variant">/ person</span>
                </div>
                <span className="text-secondary font-mono font-bold text-lg">
                  ${((bill * (1 + tipPercent / 100)) / people).toFixed(2)}
                </span>
              </div>
            </div>
          </motion.div>
        )}

        {/* DEFAULT FALLBACK - GENERAL COMING SOON VIEW */}
        {!['rating-component', 'faq-accordion', 'pod-request', 'intro-signup', 'nft-preview', 'workit-landing', 'tip-calculator'].includes(playgroundId) && (
          <motion.div
            key="fallback"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center py-8 space-y-4"
          >
            <div className="w-12 h-12 bg-surface-container-highest rounded-full flex items-center justify-center mx-auto text-on-surface-variant/40">
              <Terminal className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-display font-semibold text-on-surface">Interactive Preview Available soon</h4>
              <p className="text-xs text-on-surface-variant max-w-xs mx-auto leading-relaxed">
                The interactive sandbox for this challenge is currently compiling. Tap any "Newbie" project card to see live working widgets!
              </p>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-mono text-primary">
              <Sparkles className="w-3.5 h-3.5" /> STACK VERIFIED
            </div>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
